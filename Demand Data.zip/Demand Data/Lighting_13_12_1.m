%lm=milking facility lights
%lhf=housing facility (for cows) lights
%lod=outside area lights
Q_l=N_lm*Q_lm*T_lm+N_hf*Q_lhf*T_lhf+N_lod*Q_lod*T_lod